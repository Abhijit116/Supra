import { api } from "./api.js";
import { addToCart } from "./cart.js";
import { hasWishlisted, toggleWishlist } from "./wishlist.js";
import { notify } from "./notifications.js";

export async function renderFeaturedProducts(targetId = "featuredProducts") {
  const target = document.getElementById(targetId);
  if (!target) return;
  try {
    const products = await api.getProducts();
    target.innerHTML = products.filter(p => p.is_featured).slice(0, 4).map(productCard).join("");
    target.querySelectorAll("[data-add]").forEach(button => button.addEventListener("click", () => {
      const product = products.find(p => p.id === Number(button.dataset.add));
      if (product) { addToCart(product); notify(`${product.name} added to your bag.`); }
    }));
    target.querySelectorAll("[data-wishlist]").forEach(button => button.addEventListener("click", () => {
      const active = toggleWishlist(Number(button.dataset.wishlist));
      button.classList.toggle("is-active", active);
      button.innerHTML = `<i class="bi ${active ? "bi-heart-fill" : "bi-heart"}"></i>`;
      notify(active ? "Saved to your wishlist." : "Removed from your wishlist.");
    }));
  } catch (error) {
    console.error(error);
    target.innerHTML = `<div class="col-12"><p class="text-muted">Our collection is taking a moment to load. Please refresh to try again.</p></div>`;
  }
}
function productCard(p) {
  const wished = hasWishlisted(p.id);
  const badge = p.badge ? `<span class="product-badge">${escapeHtml(p.badge)}</span>` : "";
  const old = p.original_price ? `<span class="product-old-price">₹${Number(p.original_price).toLocaleString("en-IN")}</span>` : "";
  return `<div class="col-6 col-lg-3"><article class="product-card">
    <div class="product-image-wrap"><a href="product-details.html?id=${encodeURIComponent(p.id)}"><img src="${escapeAttr(p.image)}" alt="${escapeAttr(p.image_alt || p.name)}" loading="lazy"></a>${badge}
      <div class="product-actions"><button class="product-action ${wished ? "is-active" : ""}" data-wishlist="${p.id}" aria-label="Toggle wishlist"><i class="bi ${wished ? "bi-heart-fill" : "bi-heart"}"></i></button></div>
    </div>
    <div class="product-info"><span class="product-category">${escapeHtml(p.category_name)}</span><h3 class="product-name">${escapeHtml(p.name)}</h3>
      <div><span class="product-price">₹${Number(p.price).toLocaleString("en-IN")}</span>${old}<span class="product-rating"><i class="bi bi-star-fill"></i> ${Number(p.rating).toFixed(1)}</span></div>
      <button class="quick-add" data-add="${p.id}">Add to bag <i class="bi bi-arrow-up-right"></i></button>
    </div></article></div>`;
}
function escapeHtml(value="") { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function escapeAttr(value="") { return escapeHtml(value); }
