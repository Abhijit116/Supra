import { APP_CONFIG } from "./config.js";

/**
 * Central data adapter. UI modules call these methods rather than reading
 * JSON or making fetch requests directly. Replace the mock methods with
 * PHP fetch() calls when the backend is ready; keep the response contract.
 */
async function readJson(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Unable to load ${path}`);
  return response.json();
}
export const api = {
  async getProducts() {
    if (APP_CONFIG.api.mode === "live") return request("/products");
    return readJson("../../data/products.json").catch(() => readJson("data/products.json"));
  },
  async getTestimonials() {
    return readJson("../../data/testimonials.json").catch(() => readJson("data/testimonials.json"));
  },
  async request(endpoint, options = {}) {
    const response = await fetch(`${APP_CONFIG.api.baseUrl}${endpoint}`, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options
    });
    const payload = await response.json();
    if (!response.ok || payload.success === false) throw new Error(payload.message || "Request failed");
    return payload;
  }
};
