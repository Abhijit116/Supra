export function notify(message) {
  const container = document.getElementById("toastContainer");
  if (!container || !window.bootstrap) return;
  const toast = document.createElement("div");
  toast.className = "toast toast-supra align-items-center";
  toast.setAttribute("role", "status");
  toast.innerHTML = `<div class="d-flex"><div class="toast-body"></div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
  toast.querySelector(".toast-body").textContent = message;
  container.append(toast);
  const instance = new bootstrap.Toast(toast, { delay: 2600 });
  toast.addEventListener("hidden.bs.toast", () => toast.remove());
  instance.show();
}
