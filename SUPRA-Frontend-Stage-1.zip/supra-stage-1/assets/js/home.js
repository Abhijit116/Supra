import { renderFeaturedProducts } from "./products.js";
import { updateCartCount } from "./cart.js";
import { updateWishlistCount } from "./wishlist.js";
import { api } from "./api.js";
import { notify } from "./notifications.js";

document.addEventListener("DOMContentLoaded", async () => {
  updateCartCount();
  updateWishlistCount();
  await renderFeaturedProducts();
  renderTestimonials();
  setupHeader();
  setupReveal();
  setupNewsletter();
  setupSearch();
  setupUtilities();
  document.getElementById("currentYear").textContent = new Date().getFullYear();
});

async function renderTestimonials() {
  const target = document.getElementById("testimonials");
  if (!target) return;
  try {
    const items = await api.getTestimonials();
    target.innerHTML = items.slice(0, 3).map(item => `<div class="col-md-4"><article class="testimonial-card"><div class="testimonial-stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>“${safe(item.quote)}”</blockquote><div class="testimonial-person">${safe(item.name)}</div><div class="testimonial-product">${safe(item.product)}</div></article></div>`).join("");
  } catch (error) { console.warn("Testimonials unavailable", error); }
}
function setupHeader() {
  const header = document.getElementById("siteHeader");
  const top = document.getElementById("backToTop");
  const onScroll = () => {
    header.classList.toggle("is-scrolled", window.scrollY > 20);
    top.classList.toggle("is-visible", window.scrollY > 500);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}
function setupReveal() {
  const elements = document.querySelectorAll(".hero-copy,.section-heading,.category-card,.product-card,.story-copy,.story-image-wrap,.testimonial-card");
  elements.forEach(el => el.classList.add("reveal"));
  if (!("IntersectionObserver" in window)) { elements.forEach(el => el.classList.add("is-revealed")); return; }
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.classList.add("is-revealed"); observer.unobserve(entry.target); }
  }), { threshold: .12 });
  elements.forEach(el => observer.observe(el));
}
function setupNewsletter() {
  const form = document.getElementById("newsletterForm");
  form?.addEventListener("submit", event => {
    event.preventDefault();
    const input = document.getElementById("newsletterEmail");
    const message = document.getElementById("newsletterMessage");
    if (!input.checkValidity()) { input.reportValidity(); return; }
    message.textContent = "Thank you — you're on the list for this frontend demo.";
    message.style.color = "#D8B1B8";
    form.reset();
  });
}
function setupSearch() {
  document.getElementById("searchForm")?.addEventListener("submit", event => {
    event.preventDefault();
    const query = document.getElementById("siteSearch").value.trim();
    if (!query) return;
    window.location.href = `shop.html?search=${encodeURIComponent(query)}`;
  });
}
function setupUtilities() {
  document.querySelector(".announcement-close")?.addEventListener("click", () => document.querySelector(".announcement-bar")?.remove());
  document.getElementById("backToTop")?.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}
function safe(value="") { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
