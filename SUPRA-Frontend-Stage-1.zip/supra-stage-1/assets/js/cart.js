import { APP_CONFIG } from "./config.js";
const key = APP_CONFIG.storageKeys.cart;
function read() { try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; } }
function write(items) { localStorage.setItem(key, JSON.stringify(items)); updateCartCount(); }
export function getCart() { return read(); }
export function addToCart(product, quantity = 1) {
  const items = read();
  const existing = items.find(item => item.productId === product.id);
  if (existing) existing.quantity += quantity;
  else items.push({ productId: product.id, name: product.name, price: product.price, image: product.image, quantity });
  write(items);
}
export function updateCartCount() {
  const count = read().reduce((sum, item) => sum + item.quantity, 0);
  document.querySelectorAll("#cartCount").forEach(el => { el.textContent = count; });
}
