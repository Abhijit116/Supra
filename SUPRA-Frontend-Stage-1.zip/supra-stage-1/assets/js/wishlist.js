import { APP_CONFIG } from "./config.js";
const key = APP_CONFIG.storageKeys.wishlist;
function read() { try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; } }
function write(items) { localStorage.setItem(key, JSON.stringify(items)); updateWishlistCount(); }
export function hasWishlisted(id) { return read().includes(id); }
export function toggleWishlist(id) {
  const items = read();
  const next = items.includes(id) ? items.filter(item => item !== id) : [...items, id];
  write(next);
  return next.includes(id);
}
export function updateWishlistCount() {
  const count = read().length;
  document.querySelectorAll("#wishlistCount").forEach(el => { el.textContent = count; });
}
