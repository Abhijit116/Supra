export const APP_CONFIG = Object.freeze({
  brand: "SUPRA",
  currency: "INR",
  currencySymbol: "₹",
  storageKeys: {
    cart: "supra_demo_cart_v1",
    wishlist: "supra_demo_wishlist_v1",
    recentlyViewed: "supra_recently_viewed_v1"
  },
  api: {
    mode: "mock", // Switch to "live" when PHP endpoints are ready.
    baseUrl: "/api"
  }
});
