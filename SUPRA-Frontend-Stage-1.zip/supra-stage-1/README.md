# SUPRA — Frontend Phase 1

A responsive premium crochet boutique homepage built with HTML5, CSS3, vanilla JavaScript ES modules and Bootstrap 5.

## Run locally
Because this project uses JavaScript modules and JSON fetch requests, run it through a local web server rather than opening `index.html` directly.

### Python
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

### VS Code
Use the Live Server extension and open `index.html`.

## Included in this phase
- Homepage with announcement bar, navigation, hero, categories, featured products, story, values, custom-order banner, testimonials, social gallery, newsletter and footer.
- Responsive layouts for mobile, tablet and desktop.
- Product cards rendered from `data/products.json`.
- Demo cart and wishlist persistence through localStorage.
- Search handoff to the planned `shop.html` route.
- Toast notifications, scroll reveal, sticky header and back-to-top.
- Central mock API adapter and separated cart, wishlist, products and notification modules.

## Important demo notes
- Cart and wishlist are browser-local demo state only.
- Newsletter submission is a frontend success state; it does not store or send email.
- Product imagery currently uses remote editorial image URLs. Replace these with SUPRA's own product photography before launch.
- Login, payment, order placement, customer data and admin operations are not implemented in this phase.
- No production authentication or payment processing is claimed.

## Future PHP integration
`assets/js/api.js` is the intended adapter boundary. Switch `APP_CONFIG.api.mode` to `live` and implement the planned PHP endpoints while preserving the response shape:
```json
{ "success": true, "message": "Request completed", "data": {} }
```
Never put database credentials, payment secrets or Firebase service-account credentials in frontend files.
